DeHub Design System
===================
This kit contains the official DeHub logo lockups and brand color palette.

logos/
  wordmark-white.png  Full wordmark for dark backgrounds
  wordmark-black.png  Full wordmark for light backgrounds
  mark-white.png      Icon mark for dark backgrounds
  mark-black.png      Icon mark for light backgrounds

See PALETTE.txt for brand colors. Usage: keep clear space around logos and
do not recolor, stretch, or add effects.
